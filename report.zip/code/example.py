import os
import time
import random

fruits = ["apple", "banana", "cherry"]
for x in fruits:
  print(x)
